package StaticProxy;

public interface Subject {
	public void doSomething();
}
