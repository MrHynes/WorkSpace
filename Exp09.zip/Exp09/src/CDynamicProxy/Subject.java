package CDynamicProxy;

public interface Subject {
	void productClothing();
}
