package CDynamicProxy;

public class RealSubject implements Subject {

	@Override
	public void productClothing() {
		System.out.println("�����·�");
	}

}
