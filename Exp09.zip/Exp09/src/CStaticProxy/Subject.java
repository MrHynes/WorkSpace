package CStaticProxy;

public interface Subject {
	void productClothing();
}
