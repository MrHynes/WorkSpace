package DynamicProxy;

public interface Subject {
	public void doSomething();
}
