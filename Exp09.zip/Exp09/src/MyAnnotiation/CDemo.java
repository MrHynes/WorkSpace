package MyAnnotiation;

public class CDemo {
	@SuppressWarnings("unchecked")
	@Deprecated
	@Override
	@MyAnnotiation(value="chengqi",key="cq")
	public String toString() {
		// TODO Auto-generated method stub
		return "hello";
	}
}
